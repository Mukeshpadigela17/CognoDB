import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";
import { runQuery, getDriver } from "./db.js";
import { QUERIES } from "./queries.js";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

function mapRecord(record) {
  const out = {};
  for (const key of record.keys) {
    let value = record.get(key);
    if (value && typeof value.toNumber === "function") value = value.toNumber();
    out[key] = value;
  }
  return out;
}

app.get("/api/health", async (_req, res) => {
  try {
    await runQuery("RETURN 1 AS ok");
    res.json({ ok: true, database: "CognoDB" });
  } catch (error) {
    res.status(503).json({ ok: false, message: "Database unavailable", detail: error.message });
  }
});

app.get("/api/stats", async (_req, res) => {
  try {
    const rows = await runQuery(QUERIES.stats);
    res.json(mapRecord(rows[0]));
  } catch (error) {
    res.status(503).json({ message: "Unable to load graph statistics.", detail: error.message });
  }
});

app.get("/api/jobs", async (req, res) => {
  try {
    const term = String(req.query.search || "").trim();
    const rows = await runQuery(term ? QUERIES.searchJobs : QUERIES.jobs, term ? { term } : {});
    res.json(rows.map(mapRecord));
  } catch (error) {
    res.status(503).json({ message: "Unable to load jobs.", detail: error.message });
  }
});

app.get("/api/jobs/:id", async (req, res) => {
  try {
    const rows = await runQuery(QUERIES.jobDetails, { jobId: req.params.id });
    if (!rows.length) return res.status(404).json({ message: "Job not found." });
    res.json(mapRecord(rows[0]));
  } catch (error) {
    res.status(503).json({ message: "Unable to load job.", detail: error.message });
  }
});

app.get("/api/developers/:id/recommendations", async (req, res) => {
  try {
    const rows = await runQuery(QUERIES.recommendations, { developerId: req.params.id });
    res.json(rows.map(mapRecord));
  } catch (error) {
    res.status(503).json({ message: "Unable to calculate recommendations.", detail: error.message });
  }
});

app.get("/api/developers/:developerId/jobs/:jobId/path", async (req, res) => {
  try {
    const rows = await runQuery(QUERIES.skillPath, {
      developerId: req.params.developerId,
      jobId: req.params.jobId
    });
    res.json(rows.map(mapRecord));
  } catch (error) {
    res.status(503).json({ message: "Unable to traverse graph.", detail: error.message });
  }
});

app.get("/api/jobs/:id/neighborhood", async (req, res) => {
  try {
    const rows = await runQuery(QUERIES.graphNeighborhood, { jobId: req.params.id });
    res.json(rows.length ? mapRecord(rows[0]) : { job: null, connections: [] });
  } catch (error) {
    res.status(503).json({ message: "Unable to load graph neighborhood.", detail: error.message });
  }
});

const distPath = path.join(__dirname, "..", "dist");
app.use(express.static(distPath));
app.get("/{*splat}", (_req, res) => {
  res.sendFile(path.join(distPath, "index.html"));
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`JobGraph server running on port ${PORT}`);
});

process.on("SIGTERM", async () => {
  try { await getDriver().close(); } catch {}
  process.exit(0);
});
