export const QUERIES = {
  stats: `
    MATCH (d:Developer)
    WITH count(d) AS developers
    OPTIONAL MATCH (s:Skill)
    WITH developers, count(s) AS skills
    OPTIONAL MATCH (j:Job)
    WITH developers, skills, count(j) AS jobs
    OPTIONAL MATCH (c:Company)
    RETURN developers, skills, jobs, count(c) AS companies
  `,

  jobs: `
    MATCH (j:Job)-[:OFFERS]->(c:Company)
    OPTIONAL MATCH (j)-[:REQUIRES]->(s:Skill)
    WITH j, c, collect(s.name) AS skills
    RETURN j.id AS id, j.title AS title, j.location AS location,
           j.level AS level, j.description AS description,
           j.salaryMin AS salaryMin, j.salaryMax AS salaryMax,
           c.name AS company, skills
    ORDER BY j.title
  `,

  jobDetails: `
    MATCH (j:Job {id: $jobId})-[:OFFERS]->(c:Company)
    OPTIONAL MATCH (j)-[:REQUIRES]->(s:Skill)
    WITH j, c, collect(s.name) AS skills
    RETURN j.id AS id, j.title AS title, j.location AS location,
           j.level AS level, j.description AS description,
           j.salaryMin AS salaryMin, j.salaryMax AS salaryMax,
           c.name AS company, skills
  `,

  searchJobs: `
    MATCH (j:Job)-[:OFFERS]->(c:Company)
    WHERE toLower(j.title) CONTAINS toLower($term)
       OR toLower(j.description) CONTAINS toLower($term)
       OR toLower(j.location) CONTAINS toLower($term)
    OPTIONAL MATCH (j)-[:REQUIRES]->(s:Skill)
    WITH j, c, collect(s.name) AS skills
    RETURN j.id AS id, j.title AS title, j.location AS location,
           j.level AS level, j.description AS description,
           j.salaryMin AS salaryMin, j.salaryMax AS salaryMax,
           c.name AS company, skills
    ORDER BY j.title
  `,

  recommendations: `
    MATCH (d:Developer {id: $developerId})-[:HAS_SKILL]->(s:Skill)<-[:REQUIRES]-(j:Job)-[:OFFERS]->(c:Company)
    WITH j, c, count(DISTINCT s) AS matchedSkills
    OPTIONAL MATCH (j)-[:REQUIRES]->(allSkills:Skill)
    WITH j, c, matchedSkills, count(DISTINCT allSkills) AS totalSkills
    RETURN j.id AS id, j.title AS title, j.location AS location,
           j.level AS level, j.salaryMin AS salaryMin, j.salaryMax AS salaryMax,
           c.name AS company, matchedSkills, totalSkills,
           round(100.0 * matchedSkills / CASE WHEN totalSkills = 0 THEN 1 ELSE totalSkills END) AS matchPercent
    ORDER BY matchPercent DESC, matchedSkills DESC, j.title
    LIMIT 10
  `,

  skillPath: `
    MATCH (d:Developer {id: $developerId})-[:HAS_SKILL]->(s:Skill)<-[:REQUIRES]-(j:Job)-[:OFFERS]->(c:Company)
    WHERE j.id = $jobId
    RETURN d.name AS developer, s.name AS skill, j.title AS job, c.name AS company
    ORDER BY skill
  `,

  graphNeighborhood: `
    MATCH (j:Job {id: $jobId})
    OPTIONAL MATCH p=(j)-[:REQUIRES]->(s:Skill)<-[:HAS_SKILL]-(d:Developer)
    RETURN j.title AS job, collect({
      skill: s.name,
      developer: d.name
    })[0..20] AS connections
  `
};
