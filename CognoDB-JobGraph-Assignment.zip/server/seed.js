import dotenv from "dotenv";
import { runQuery, closeDriver } from "./db.js";

dotenv.config();

const seed = `
CREATE CONSTRAINT developer_id IF NOT EXISTS FOR (d:Developer) REQUIRE d.id IS UNIQUE;
CREATE CONSTRAINT skill_name IF NOT EXISTS FOR (s:Skill) REQUIRE s.name IS UNIQUE;
CREATE CONSTRAINT job_id IF NOT EXISTS FOR (j:Job) REQUIRE j.id IS UNIQUE;
CREATE CONSTRAINT company_id IF NOT EXISTS FOR (c:Company) REQUIRE c.id IS UNIQUE;

UNWIND $companies AS row
MERGE (c:Company {id: row.id})
SET c.name = row.name, c.industry = row.industry, c.size = row.size;

UNWIND $skills AS row
MERGE (s:Skill {name: row.name})
SET s.category = row.category;

UNWIND $developers AS row
MERGE (d:Developer {id: row.id})
SET d.name = row.name, d.experience = row.experience;

UNWIND $jobs AS row
MERGE (j:Job {id: row.id})
SET j.title = row.title, j.location = row.location, j.level = row.level,
    j.description = row.description, j.salaryMin = row.salaryMin, j.salaryMax = row.salaryMax
WITH row
MATCH (j:Job {id: row.id}), (c:Company {id: row.companyId})
MERGE (j)-[:OFFERS]->(c)
WITH row, j
UNWIND row.skills AS skillName
MATCH (s:Skill {name: skillName})
MERGE (j)-[:REQUIRES]->(s);

UNWIND $developers AS row
MATCH (d:Developer {id: row.id})
UNWIND row.skills AS skillName
MATCH (s:Skill {name: skillName})
MERGE (d)-[:HAS_SKILL]->(s);
`;

const companies = [
  {id:"c1", name:"Nova Systems", industry:"FinTech", size:"Medium"},
  {id:"c2", name:"CloudForge", industry:"Cloud Infrastructure", size:"Large"},
  {id:"c3", name:"DataNest", industry:"Analytics", size:"Medium"},
  {id:"c4", name:"HealthGrid", industry:"HealthTech", size:"Large"},
  {id:"c5", name:"RetailPulse", industry:"E-commerce", size:"Large"}
];

const skills = [
  {name:"Java",category:"Backend"},
  {name:"Spring Boot",category:"Backend"},
  {name:"Python",category:"Backend"},
  {name:"React",category:"Frontend"},
  {name:"JavaScript",category:"Frontend"},
  {name:"SQL",category:"Data"},
  {name:"PostgreSQL",category:"Data"},
  {name:"AWS",category:"Cloud"},
  {name:"Docker",category:"DevOps"},
  {name:"Kubernetes",category:"DevOps"},
  {name:"Kafka",category:"Data"},
  {name:"Machine Learning",category:"AI"},
  {name:"FastAPI",category:"Backend"},
  {name:"TypeScript",category:"Frontend"}
];

const developers = [
  {id:"d1",name:"Aarav",experience:2,skills:["Java","Spring Boot","SQL","React","JavaScript"]},
  {id:"d2",name:"Meera",experience:3,skills:["Python","FastAPI","Machine Learning","SQL","AWS"]},
  {id:"d3",name:"Rohan",experience:4,skills:["Java","Spring Boot","AWS","Docker","Kubernetes","Kafka"]},
  {id:"d4",name:"Ishita",experience:2,skills:["React","TypeScript","JavaScript","SQL","Python"]},
  {id:"d5",name:"Kabir",experience:5,skills:["Python","Machine Learning","Kafka","SQL","AWS","Docker"]}
];

const jobs = [
  {id:"j1",title:"Junior Full Stack Engineer",location:"Hyderabad",level:"Entry",description:"Build customer-facing web features with React and Spring Boot.",salaryMin:600000,salaryMax:900000,companyId:"c1",skills:["Java","Spring Boot","React","SQL","JavaScript"]},
  {id:"j2",title:"Cloud Backend Engineer",location:"Bengaluru",level:"Mid",description:"Develop scalable backend services and cloud-native workloads.",salaryMin:1000000,salaryMax:1600000,companyId:"c2",skills:["Java","Spring Boot","AWS","Docker","Kubernetes"]},
  {id:"j3",title:"Machine Learning Engineer",location:"Pune",level:"Mid",description:"Productionize ML models and data services.",salaryMin:1100000,salaryMax:1800000,companyId:"c3",skills:["Python","Machine Learning","FastAPI","SQL","AWS"]},
  {id:"j4",title:"Frontend React Engineer",location:"Remote",level:"Entry",description:"Create accessible analytics interfaces for modern products.",salaryMin:700000,salaryMax:1100000,companyId:"c4",skills:["React","TypeScript","JavaScript","SQL"]},
  {id:"j5",title:"Data Platform Engineer",location:"Chennai",level:"Mid",description:"Build event-driven data pipelines and cloud services.",salaryMin:1200000,salaryMax:1900000,companyId:"c5",skills:["Python","Kafka","SQL","AWS","Docker"]},
  {id:"j6",title:"Java API Engineer",location:"Hyderabad",level:"Entry",description:"Design reliable REST APIs for financial workflows.",salaryMin:650000,salaryMax:950000,companyId:"c1",skills:["Java","Spring Boot","SQL","Docker"]}
];

try {
  await runQuery(seed, {companies, skills, developers, jobs});
  console.log("Seed completed successfully.");
} catch (error) {
  console.error("Seed failed:", error.message);
  process.exitCode = 1;
} finally {
  await closeDriver();
}
