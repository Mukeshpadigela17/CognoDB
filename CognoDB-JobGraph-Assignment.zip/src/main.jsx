import React, { useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import "./styles.css";

const API = "/api";

function App() {
  const [stats, setStats] = useState(null);
  const [jobs, setJobs] = useState([]);
  const [recommendations, setRecommendations] = useState([]);
  const [selectedJob, setSelectedJob] = useState(null);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [recLoading, setRecLoading] = useState(false);
  const [error, setError] = useState("");

  async function loadJobs(term = "") {
    setLoading(true);
    setError("");
    try {
      const response = await fetch(`${API}/jobs${term ? `?search=${encodeURIComponent(term)}` : ""}`);
      if (!response.ok) throw new Error("Could not connect to CognoDB.");
      setJobs(await response.json());
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  async function loadRecommendations() {
    setRecLoading(true);
    try {
      const response = await fetch(`${API}/developers/d1/recommendations`);
      if (!response.ok) throw new Error("Recommendation query failed.");
      setRecommendations(await response.json());
    } catch (e) {
      setError(e.message);
    } finally {
      setRecLoading(false);
    }
  }

  useEffect(() => {
    Promise.all([
      fetch(`${API}/stats`).then(r => r.ok ? r.json() : Promise.reject()),
      loadJobs()
    ]).then(([s]) => setStats(s))
      .catch(() => setError("CognoDB is unreachable. Check your environment variables."));
    loadRecommendations();
  }, []);

  const displayedJobs = useMemo(() => jobs, [jobs]);

  return (
    <div className="app-shell">
      <header className="topbar">
        <div className="brand">
          <div className="brand-mark">JG</div>
          <div>
            <strong>JobGraph</strong>
            <span>Powered by CognoDB</span>
          </div>
        </div>
        <div className="status"><i /> Graph database connected</div>
      </header>

      <main>
        <section className="hero">
          <div>
            <p className="eyebrow">GRAPH-BASED JOB DISCOVERY</p>
            <h1>Find opportunities through <em>connections.</em></h1>
            <p className="hero-copy">
              Explore how developer skills connect to jobs, companies and related talent.
              Recommendations are calculated by traversing the graph.
            </p>
          </div>
          <div className="hero-card">
            <span>Example profile</span>
            <strong>Aarav</strong>
            <p>Java · Spring Boot · React · SQL</p>
            <small>5 skills connected to the graph</small>
          </div>
        </section>

        {error && <div className="alert"><strong>Connection issue:</strong> {error}</div>}

        <section className="stats">
          {[
            ["Developers", stats?.developers ?? "—"],
            ["Skills", stats?.skills ?? "—"],
            ["Jobs", stats?.jobs ?? "—"],
            ["Companies", stats?.companies ?? "—"]
          ].map(([label, value]) => <div className="stat" key={label}><span>{label}</span><strong>{value}</strong></div>)}
        </section>

        <section className="workspace">
          <div className="section-heading">
            <div>
              <p className="eyebrow">EXPLORE THE GRAPH</p>
              <h2>Open roles</h2>
            </div>
            <div className="search">
              <span>⌕</span>
              <input value={search} onChange={e => { setSearch(e.target.value); loadJobs(e.target.value); }} placeholder="Search jobs, skills or location..." />
            </div>
          </div>

          {loading ? <div className="empty">Loading jobs from CognoDB…</div> :
           displayedJobs.length === 0 ? <div className="empty">No matching jobs found.</div> :
           <div className="job-grid">
             {displayedJobs.map(job => (
               <button className={`job-card ${selectedJob?.id === job.id ? "selected" : ""}`} key={job.id} onClick={() => setSelectedJob(job)}>
                 <div className="job-top"><span className="level">{job.level}</span><span>↗</span></div>
                 <h3>{job.title}</h3>
                 <p className="company">{job.company} · {job.location}</p>
                 <p className="description">{job.description}</p>
                 <div className="chips">{job.skills.map(s => <span key={s}>{s}</span>)}</div>
                 <div className="salary">₹{(job.salaryMin/100000).toFixed(1)}L – ₹{(job.salaryMax/100000).toFixed(1)}L</div>
               </button>
             ))}
           </div>
          }
        </section>

        <section className="recommend">
          <div className="section-heading">
            <div>
              <p className="eyebrow">MULTI-HOP TRAVERSAL</p>
              <h2>Recommended for Aarav</h2>
            </div>
            <button className="outline" onClick={loadRecommendations}>Refresh matches</button>
          </div>
          <p className="muted">Developer → Skill → Job → Company. The score reflects the percentage of required skills Aarav already has.</p>
          {recLoading ? <div className="empty">Traversing graph…</div> :
          <div className="rec-list">
            {recommendations.map((r, i) => (
              <div className="rec" key={r.id}>
                <div className="rank">{String(i+1).padStart(2,"0")}</div>
                <div className="rec-main">
                  <strong>{r.title}</strong>
                  <span>{r.company} · {r.location}</span>
                </div>
                <div className="match"><strong>{r.matchPercent}%</strong><span>{r.matchedSkills}/{r.totalSkills} skills</span></div>
                <div className="bar"><i style={{width: `${r.matchPercent}%`}} /></div>
              </div>
            ))}
          </div>}
        </section>

        {selectedJob && (
          <section className="detail">
            <div>
              <p className="eyebrow">SELECTED NODE</p>
              <h2>{selectedJob.title}</h2>
              <p>{selectedJob.company} · {selectedJob.location} · {selectedJob.level}</p>
            </div>
            <div className="path">
              <span>Aarav</span><b>HAS_SKILL →</b><span>{selectedJob.skills[0]}</span><b>→ REQUIRES</b><span>{selectedJob.title}</span><b>→ OFFERS</b><span>{selectedJob.company}</span>
            </div>
            <button className="close" onClick={() => setSelectedJob(null)}>Close</button>
          </section>
        )}
      </main>

      <footer>JobGraph · WEXA AI CognoDB Assignment · Graph-first job discovery</footer>
    </div>
  );
}

createRoot(document.getElementById("root")).render(<App />);
