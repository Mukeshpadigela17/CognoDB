// Multi-hop: developer -> skill -> job -> company
MATCH (d:Developer {id: $developerId})-[:HAS_SKILL]->(s:Skill)<-[:REQUIRES]-(j:Job)-[:OFFERS]->(c:Company)
RETURN d.name AS developer, collect(DISTINCT j.title) AS jobs, collect(DISTINCT c.name) AS companies;

// Graph-specific recommendation: rank jobs by overlap of developer skills.
MATCH (d:Developer {id: $developerId})-[:HAS_SKILL]->(s:Skill)<-[:REQUIRES]-(j:Job)-[:OFFERS]->(c:Company)
WITH j, c, count(DISTINCT s) AS matchedSkills
MATCH (j)-[:REQUIRES]->(required:Skill)
WITH j, c, matchedSkills, count(DISTINCT required) AS totalSkills
RETURN j.title, c.name, matchedSkills, totalSkills,
       round(100.0 * matchedSkills / totalSkills) AS matchPercent
ORDER BY matchPercent DESC;

// Skills connecting a developer to one target job.
MATCH (d:Developer {id: $developerId})-[:HAS_SKILL]->(s:Skill)<-[:REQUIRES]-(j:Job {id: $jobId})
RETURN d.name, s.name, j.title;
